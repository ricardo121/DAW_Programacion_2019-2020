public class Ejercicio10 {
}
