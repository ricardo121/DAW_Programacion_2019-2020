import java.util.Scanner;

public class Ejercicio7 {

    public static boolean primo(int numero) {
        int contador = 2;
        boolean primo=true;

        while (contador<numero){
            if (numero % contador == 0) {
                primo = false;
                break;
            }
            contador++;
        }
        return primo;
    }

    public static void main(String args[]) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Introduzca un primer numero: ");
        int numero=teclado.nextInt();

        System.out.print("Es primo :");
        System.out.print(primo(numero));
    }

}
