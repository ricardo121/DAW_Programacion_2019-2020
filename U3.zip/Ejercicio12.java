public class Ejercicio12 {

    //https://www.lawebdelprogramador.com/codigo/Java/4561-Calcular-el-factorial-de-n-recursivamente.html

}
