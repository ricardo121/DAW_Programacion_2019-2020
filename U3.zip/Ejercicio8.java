import java.util.Scanner;

public class Ejercicio8 {


    public static boolean primo(int numero) {
        int contador = 2;
        boolean primo=true;

        while (contador<numero){
            if (numero % contador == 0) {
                primo = false;
                break;
            }
            contador++;
        }
        return primo;
    }

    public static int divisores_primo(int divisores) {
        int num_divisores = 0;
        for (int i = 2 ; i <= divisores ; i++){
            if (divisores % i == 0 && primo(i)) {
                System.out.println("El numero "+ i +" es divisor y primo");
                num_divisores++;

            }
        }
        return num_divisores;
    }

    public static void main(String args[]) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Introduzca un primer numero: ");
        int numero=teclado.nextInt();
        teclado.nextLine();

        System.out.print("El numero "+ numero + " tiene "+divisores_primo(numero)+" numero/s primo/s");
        teclado.close();
    }

}
