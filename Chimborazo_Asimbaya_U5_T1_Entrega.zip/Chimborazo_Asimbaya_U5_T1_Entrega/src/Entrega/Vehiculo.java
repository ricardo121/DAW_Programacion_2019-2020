package Entrega;
public class Vehiculo  {

    //(public enum vehiculo {Terrestre,Aereo}
    //protected vehiculo vehi;

    protected int pasajeros ;
    public String nombre;




    public Vehiculo(String nombre) {
        this.nombre = nombre;
        pasajeros = 1;
    }

    public void transportar(int pasajeros){

            pasajeros ++;


    }




}
