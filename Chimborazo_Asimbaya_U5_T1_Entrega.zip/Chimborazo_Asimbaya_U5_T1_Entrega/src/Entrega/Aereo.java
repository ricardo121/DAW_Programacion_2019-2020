
package Entrega;

public class Aereo extends Vehiculo{




        public Aereo(){

            super(null);

        }


}
