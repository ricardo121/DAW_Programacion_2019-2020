import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String args[]) {

        int longitud ;
        Scanner teclado = new Scanner(System.in);
        boolean primo=true;
        String palabra_fin = "fin";


        while(primo = true){

            System.out.print("introduzca palabra: ");

            String palabra = teclado.nextLine();
            int contador = 0;
            int[] t = new int[cantidad];

            if (palabra.equals(palabra_fin)){

                primo = false;
                break;

            }
            ++contador;


        }

        //longitud = frase.length() / 2 ;
        //String mitad = frase.substring(longitud, longitud + 1);
        //String espacio = " ";
        //if (mitad.equals(espacio)) {
          //  System.out.println("Es un espacio");
        //} else {
          //  System.out.println("No es un espacio");
        //}


    }

}
